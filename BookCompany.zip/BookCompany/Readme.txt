				ABC Book Company
This program is a book management program that handles several activities like checking out a book, finding a book by its title, 
displaying a book by it's type or to look for a random book. Also, this program updates the database for the book company like the 
book availibity.

Date: 12 Feburary 2021
Authors: Nagi Nabal, Prince Bansal, Akshat Sawaraj
 
There are 2 ways to run program
1) Running from the jar file by using the command: java -jar Akshat.Swaraj.Nagi.Nabal.Prince.Bansal.jar
2) Run the program from the Eclipse Editor